import React, { useState } from "react";

function Calculator() {
  const [result, setResult] = useState(0);
  const [value, setValue] = useState("");
  const handleInputChange = (e) => {
    setValue(e.target.value);
  };

  const handleOperation = (operation) => {
    if (value.trim() === "") return; 
    const num = parseFloat(value);
    if (isNaN(num)) return; 

    setResult((prevResult) => {
      switch (operation) {
        case "add":
          return prevResult + num;
        case "subtract":
          return prevResult - num;
        case "multiply":
          return prevResult * num;
        case "divide":
          return num !== 0 ? prevResult / num : "Cannot divide by zero";
        default:
          return prevResult;
      }
    });

    setValue(""); 
  };

  const resetInput = () => {
    setValue("");
  };

  const resetResult = () => {
    setResult(0);
  };

  return (
    <div style={{ textAlign: "center", marginTop: "50px" }}>
      <h2>Simplest Working Calculator</h2>
      <h3>{result}</h3>
      <input
        type="number"
        value={value}
        onChange={handleInputChange}
        placeholder="Enter number"
      />
      <br />
      <br />
      <div>
        <button onClick={() => handleOperation("add")}>add</button>
        <button onClick={() => handleOperation("subtract")}>subtract</button>
        <button onClick={() => handleOperation("multiply")}>multiply</button>
        <button onClick={() => handleOperation("divide")}>divide</button>
        <button
          onClick={resetInput}
          style={{ backgroundColor: "red", color: "white" }}
        >
          reset input
        </button>
        <button
          onClick={resetResult}
          style={{ backgroundColor: "red", color: "white" }}
        >
          reset result
        </button>
      </div>
    </div>
  );
}

export default Calculator;
